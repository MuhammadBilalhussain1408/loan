﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace LoanManagementSystem.DomainModels
{
    public class HomeLoans
    {
        
    [Key]
        public int Id { get; set; }

        public DateTime? ApplicationDate { get; set; }

        public decimal? Amount { get; set; }

        [StringLength(50)]
        public string Reason { get; set; }

        [StringLength(50)]
        public string FinancialRecommendation { get; set; }

        public DateTime? FinancialRecommendationDate { get; set; }

        public int? FinancialRecommendationId { get; set; }

        [StringLength(50)]
        public string ManagementRecommendation { get; set; }

        public DateTime? ManagementRecommendationDate { get; set; }

        public int? ManagementRecommendationId { get; set; }

        public int? LoanStatus { get; set; }

        public DateTime? LoanStatusChangeDate { get; set; }

        public int? CurrentLoanId { get; set; }

        [Column(TypeName = "nchar(10)")]
        public string UserId { get; set; }

        [ForeignKey("CurrentLoanId")]
        public virtual HomeLoans CurrentLoan { get; set; }
    }
}
