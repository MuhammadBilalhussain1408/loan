﻿namespace LoanManagementSystem.DomainModels
{
    public class CurrentLoansView
    {
        public int Id { get; set; }
        public string Fsp { get; set; }
        public string Amount { get; set; }
        public string Year { get; set; }
        public int UserId { get; set; }
    }
}
