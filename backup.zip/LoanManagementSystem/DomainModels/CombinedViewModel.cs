﻿namespace LoanManagementSystem.DomainModels
{
    public class CombinedViewModel
    {
        public DashboardViewModel UserDetails { get; set; }
        public List<CurrentLoans> Loans { get; set; }
    }
}
