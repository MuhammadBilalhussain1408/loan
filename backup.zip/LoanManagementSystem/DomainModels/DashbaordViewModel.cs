﻿using System.ComponentModel.DataAnnotations;
using static LoanManagementSystem.CommonSetup.CommonEnums;

namespace LoanManagementSystem.DomainModels
{
    public class DashboardViewModel
    {
        [Key]
        public long Id { get; set; }
        public int? SrNo { get; set; }

        public long MId { get; set; }
        public string emp_id { get; set; }
        public string FirstName { get; set; }
        public string Initials { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string DisplayName { get; set; }
        public string Pin { get; set; }
        public string Email { get; set; }
        public bool? EmailConfirmed { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public Gender? Gender { get; set; }
        public RoleType? RoleType { get; set; }
        public string PasswordHash { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime? LastLoggedIn { get; set; }
        public string SerialNumber { get; set; }
        public bool IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public DateTime? DeletedAt { get; set; }
        public Guid? CreatedBy { get; set; }
        public Guid? UpdatedBy { get; set; }
        public Guid? DeletedBy { get; set; }
    }

    public class CurrentLoans
    {
        public int Id { get; set; }
        public string Fsp { get; set; }
        public decimal Amount { get; set; }
        public DateOnly Year { get; set; }
        public long User_Id { get; set; }
    }

    //public class HomeLoans
    //{
    //    public int Id { get; set; }
    //    public string Fsp { get; set; }
    //    public decimal Amount { get; set; }
    //    public DateOnly Year { get; set; }
    //    public long User_Id { get; set; }
    //}


}
