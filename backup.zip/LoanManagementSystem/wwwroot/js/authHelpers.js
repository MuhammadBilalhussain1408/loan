﻿// wwwroot/js/authHelpers.js

// Function to get the JWT token from local storage
function getToken() {
    return localStorage.getItem("jwtToken");
}

// Function to make an API request with the JWT token in the Authorization header
function apiFetch(url, options = {}) {
    const token = getToken();

    if (token) {
        options.headers = {
            ...options.headers,
            "Authorization": `${token}`,
            "Content-Type": "application/json"
        };
    }

    return fetch(url, options);
}

// Export the functions to be used in other scripts
export { getToken, apiFetch };
