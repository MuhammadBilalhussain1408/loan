﻿namespace LoanManagementSystem.CommonSetup
{
    public static class CommonEnums
    {




        public enum ResponseType
        {
            Success = 1,
            Failure = 2,
            SuccessId = 3,
        }
        public enum RoleType
        {
            SuperAdmin = 1,
            Admin = 2,
            User = 3,
        }
        public enum Gender
        {
            Male = 1,
            Female = 2,
            Others = 3,
        }



    }
}
