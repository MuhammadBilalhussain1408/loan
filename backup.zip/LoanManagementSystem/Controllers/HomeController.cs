﻿using LoanManagementSystem.DomainModels;
using LoanManagementSystem.DTO;
using LoanManagementSystem.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LoanManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _appDbContext;
        private readonly IConfiguration _config;

        public HomeController(ILogger<HomeController> logger, IConfiguration config, AppDbContext appDbContext)
        {
            _logger = logger;
            _config = config;
            _appDbContext = appDbContext;
        }

        public IActionResult Index()
        {
            // Assuming you have a method to get the current logged-in user
            var user = GetCurrentLoggedInUser();

            if (user != null)
            {
                var model = new DashboardViewModel
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    DisplayName = user.DisplayName
                    // Set other properties as needed
                };

                return View(model);
            }
            return View();
        }


        private User GetCurrentLoggedInUser()
        {
            var userId = User.FindFirst("Id")?.Value;

            if (!string.IsNullOrEmpty(userId))
            {
                return _appDbContext.Users.FirstOrDefault(u => u.Pin == userId);
            }

            return null;
        }


        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] UserLogin model)
        {
            var user = _appDbContext.Users.Where(a => a.Pin == model.UserName && a.Password == model.Password).FirstOrDefault();
            if (user == null)
            {
                return Unauthorized();
            }

            var now = DateTime.UtcNow;
            var secretKey = _config.GetValue<string>("JwtSettings:SecretKey");
            var issuer = _config.GetValue<string>("JwtSettings:Issuer");
            var audience = _config.GetValue<string>("JwtSettings:Audience");

            //var key = Encoding.ASCII.GetBytes(secretKey);
            var authClaims = new List<Claim>
                    {
                                new(ClaimTypes.Email, user.Username),
                                new("userId", user.Pin),
                                new("expires", now.AddMinutes(120).ToString())
                     };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: authClaims,
                notBefore: now,
                expires: now.AddMinutes(120),
                signingCredentials: creds);
            var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
            var identity = new ClaimsIdentity(authClaims, CookieAuthenticationDefaults.AuthenticationScheme);
            var userPrincipal = new ClaimsPrincipal(new[] { identity });
            try
            {
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, userPrincipal);

                // Update LastLoggedIn time
                user.LastLoggedIn = now;
                _appDbContext.Users.Update(user);
                await _appDbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }

            // Prepare the user details to return
            var userDetails = new
            {
                user.Id,
                user.SrNo,
                user.MId,
                user.emp_id,
                user.FirstName,
                user.Initials,
                user.MiddleName,
                user.LastName,
                user.DisplayName,
                user.Pin,
                user.Email,
                user.EmailConfirmed,
                user.Username,
                user.Gender,
                user.RoleType,
                user.PhoneNumber,
                user.LastLoggedIn,
                user.SerialNumber,
                user.IsActive,
                user.CreatedAt,
                user.UpdatedAt
            };

            // Store user details in TempData
            TempData["UserDetails"] = JsonConvert.SerializeObject(userDetails);

            return Ok(new { Token = tokenString, UserDetails = userDetails });
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
