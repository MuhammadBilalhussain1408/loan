﻿using LoanManagementSystem.DomainModels;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Security.Claims;

namespace LoanManagementSystem.Controllers
{
    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    //[Authorize]
    public class DashboardController : Controller
    {
        private readonly IConfiguration _config;
        private readonly AppDbContext _appDbContext;
        public DashboardController(IConfiguration config, AppDbContext appDbContext)
        {
            _config = config;
            _appDbContext = appDbContext;
        }


        public IActionResult Index()
        {
            var claims = HttpContext.User.Claims;
            var userId = claims.FirstOrDefault(claim => claim.Type == ClaimTypes.NameIdentifier)?.Value;
            var userName = claims.FirstOrDefault(claim => claim.Type == "userId")?.Value;
            var email = claims.FirstOrDefault(claim => claim.Type == ClaimTypes.Email)?.Value;
            //var id = claims.FirstOrDefault(claim => claim.Type == "Id")?.Value;
            if (TempData["UserDetails"] != null)
            {

                var userDetailsJson = TempData["UserDetails"].ToString();
                var userDetails = JsonConvert.DeserializeObject<DashboardViewModel>(userDetailsJson);


                var loans = _appDbContext.CurrentLoans
                    .Where(cl => cl.User_Id == userDetails.Id)
                    .Select(cl => new CurrentLoans
                    {
                        Fsp = cl.Fsp,
                        Amount = cl.Amount,
                        Year = cl.Year
                    })
                    .ToList();
                var Combined = new CombinedViewModel{ UserDetails =  userDetails, Loans = loans };
                return View(Combined);

                //return View(userDetails);
            }


            return View();
        }


        [HttpPost]
        [Route("Home/SubmitForm2")]
        public IActionResult SubmitForm([FromBody] List<CurrentLoans> form1Data, HomeLoans loan)//CurrentLoans formSubmission)
        {
            if (ModelState.IsValid)
            {
                _appDbContext.CurrentLoans.AddRange(form1Data);
                _appDbContext.HomeLoan.Add(loan);
                _appDbContext.SaveChanges();
                //TempData["Success"] = "Form submitted successfully!";
                return Json(new { success = true, message = "Form 1 submitted successfully!" });
            }
            //else
            //{
            //    TempData["Error"] = "There was an error submitting the form.";
            //}

            return Json(new { success = false, message = "There was an error submitting Form 1." });
        }
    }
}
