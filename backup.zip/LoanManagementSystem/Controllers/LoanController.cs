﻿using Microsoft.AspNetCore.Mvc;

namespace LoanManagementSystem.Controllers
{
    public class LoanController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
