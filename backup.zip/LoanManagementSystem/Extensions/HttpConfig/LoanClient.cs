﻿namespace LoanManagementSystem.Extensions.HttpConfig
{
    public class LoanClient
    {
    }
}
